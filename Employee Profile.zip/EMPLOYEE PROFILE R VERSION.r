# Assuming R is set up to work with the directory containing the zipped folder
zip_file <- "Employee_Profile.zip"
unzip(zip_file, exdir = "Employee_Profile")

# Read CSV data into R data frame
employee_data <- read.csv("Employee Profile.zipfile/NATHANIEL FORD.csv")

# Display the data
print(employee_data)
