#Class Payment

class Payment:
    #Initialize a payment with ID, policyholder ID, amount and date)
    def __init__(self, policyholder, product, amount):
        self.policyholder = policyholder
        self.product = product
        self.amount = amount
        self.date = date

    #Process the payment
    def process_payment(self):
        print(f"Processed payment of {self.amount} for policyholder ID {self.policyholder_id} on {self.date}.")
       
        #Send a payment reminder
    def send_reminder(self):
        print(f"Reminder: Payment of {self.amount} for policyholder ID {self.policyholder_id} is due.")
        

        #Apply a penalty for overdue payment
    def apply_penalty(self):
        print(f"Penalty of {penalty_amount} applied to policyholder ID {self.policyholder_id}.")
        
