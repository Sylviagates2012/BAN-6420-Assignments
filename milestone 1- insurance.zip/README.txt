# Policy Management System

## Introduction
This system manages policyholders, products, and payments for an insurance company. It allows policy managers to perform various tasks such as adding and suspending policyholders, registering new members, and managing policy products.

## File Structure
- `Policyholder.py`: Contains the Policyholder class.
- `Product.py`: Contains the Product class.
- `Payment.py`: Contains the Payment class.
- `main.py`: Main script to demonstrate the functionality.

## Usage
1. Ensure you have Python installed on your system.
2. Download the files or clone the repository.
3. Run `main.py` to see the demonstration of the system.
