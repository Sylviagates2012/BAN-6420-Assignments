#Policy Holder Demonstration

import sys
sys.path.append(r'C:\Users\USER\Downloads')

from Policyholder import Policyholder
from Product import Product
from Payment import Payment



from Policyholder import Policyholder
from Product import Product
from Payment import Payment

# Create policyholders
policyholder1 = Policyholder("Ada Ade", "POL001")
policyholder2 = Policyholder("Jide Tobi", "POL002")

# Create products
product1 = Product("Life Insurance", 100)
product2 = Product("Health Insurance", 150)

# Demonstrate payment
payment1 = Payment(policyholder1, product1, 100)
payment1.process_payment()

payment2 = Payment(policyholder2, product2, 150)
payment2.process_payment()

# Display account details
print("Policyholder 1 Details:")
print("Name:", policyholder1.name)
print("Policy Number:", policyholder1.policy_number)
print("Is Active:", policyholder1.is_active)

print("\nPolicyholder 2 Details:")
print("Name:", policyholder2.name)
print("Policy Number:", policyholder2.policy_number)
print("Is Active:", policyholder2.is_active)
