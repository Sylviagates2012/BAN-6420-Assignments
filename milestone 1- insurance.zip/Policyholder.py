#Milestone 1 Assignment

class Policyholder:
    #Initialize a policyholder with ID and name
    def __init__(self, name, policy_number, is_active=True):
        self.name = name
        self.policy_number = policy_number
        self.is_active = is_active

    #Suspend a policyholder
    def suspend(self):
        self.is_active = False

    #Reactivate a suspended policyholder
    def reactivate(self):
        self.is_active = True
