#Class Product
class Product:
    #Initialize a product with ID, name, and details
    def __init__(self, name, price, is_active=True):
        self.name = name
        self.price = price
        self.is_active = is_active

        #Update the product's name and/or details
    def update(self, name, is_active=True):
        self.name = name
        self.is_active = is_active
        print(f"Product ID {self.is_active} updated.")

    #suspend policy product
    def suspend(self):
        self.is_active = False

    #reactivate policy product
    def reactivate(self):
        self.is_active = True
