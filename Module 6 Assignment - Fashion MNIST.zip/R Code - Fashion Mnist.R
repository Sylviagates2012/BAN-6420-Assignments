# Load necessary libraries
library(keras)
library(tensorflow)

# Load Fashion MNIST dataset
fashion_mnist <- dataset_fashion_mnist()
train_images <- fashion_mnist$train$x
train_labels <- fashion_mnist$train$y
test_images <- fashion_mnist$test$x
test_labels <- fashion_mnist$test$y

# Class names
class_names <- c('T-shirt/top', 'Trouser', 'Pullover', 'Dress', 'Coat',
                 'Sandal', 'Shirt', 'Sneaker', 'Bag', 'Ankle boot')

# Checking the shape of database
cat("Training images shape:", dim(train_images), "\n")
cat("Training labels shape:", length(train_labels), "\n")
cat("Test images shape:", dim(test_images), "\n")
cat("Test labels shape:", length(test_labels), "\n")

# Scaling the values to a range of 0 to 1 before feeding to the neural network model
train_images <- train_images / 255
test_images <- test_images / 255

# Reshape data for CNN
train_images <- array_reshape(train_images, c(dim(train_images)[1], 28, 28, 1))
test_images <- array_reshape(test_images, c(dim(test_images)[1], 28, 28, 1))

# Define the CNN architecture
model <- keras_model_sequential()
model <- model %>%
  layer_conv_2d(filters = 32, kernel_size = c(3, 3), activation = 'relu', input_shape = c(28, 28, 1))
model <- model %>%
  layer_max_pooling_2d(pool_size = c(2, 2))
model <- model %>%
  layer_conv_2d(filters = 64, kernel_size = c(3, 3), activation = 'relu')
model <- model %>%
  layer_max_pooling_2d(pool_size = c(2, 2))
model <- model %>%
  layer_flatten()
model <- model %>%
  layer_dense(units = 128, activation = 'relu')
model <- model %>%
  layer_dense(units = 10, activation = 'softmax')

# Compile the model
model %>% compile(
  optimizer = 'adam',
  loss = 'sparse_categorical_crossentropy',
  metrics = c('accuracy')
)

# Train the model
history <- model %>% fit(
  train_images, train_labels,
  epochs = 5
)

# Evaluate the model
model %>% evaluate(test_images, test_labels)

# Make predictions for the first two images
predictions <- model %>% predict(test_images[1:2,,])
cat('Predictions for first two images:', max.col(predictions), '\n')

# Plot the first two test images, their predicted label, and the true label
par(mfrow=c(1,2))
for (i in 1:2) {
  image <- test_images[i,,]
  plot(as.raster(image), main=paste("Predicted:", class_names[max.col(predictions[i])], "\nTrue Label:", class_names[test_labels[i]]), axes=FALSE)
}

# Making predictions for the 12th model
prediction_12th <- max.col(predictions[12])
cat("Prediction for the 12th model:", class_names[prediction_12th], "\n")
