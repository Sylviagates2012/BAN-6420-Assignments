worker_list <- list()

for (i in 1:400) {
  name <- paste("Worker", i)
  hourly_rate <- 20
  hours_worked <- 40 + (i %% 10)
  gender <- ifelse(i %% 2 == 0, "Male", "Female")
  worker_list[[i]] <- list(name = name, hourly_rate = hourly_rate, hours_worked = hours_worked, gender = gender)
}

calculate_payment <- function(hourly_rate, hours_worked) {
  regular_hours <- min(hours_worked, 40)
  overtime_hours <- max(hours_worked - 40, 0)
  regular_payment <- regular_hours * hourly_rate
  overtime_payment <- overtime_hours * (hourly_rate * 1.5)
  total_payment <- regular_payment + overtime_payment
  return(total_payment)
}

determine_level <- function(total_payment, gender) {
  if (10000 < total_payment && total_payment < 20000) {
    return("A1")
  } else if (7500 < total_payment && total_payment < 30000 && gender == "Female") {
    return("A5-F")
  } else {
    return("Unknown")
  }
}

for (worker in worker_list) {
  tryCatch({
    total_payment <- calculate_payment(worker$hourly_rate, worker$hours_worked)
    level <- determine_level(total_payment, worker$gender)
    cat("Name:", worker$name, "\n")
    cat("Total Payment:", sprintf("$%.2f", total_payment), "\n")
    cat("Employee Level:", level, "\n\n")
  }, error = function(e) {
    cat("Error processing payment for", worker$name, ":", conditionMessage(e), "\n")
  })
}
