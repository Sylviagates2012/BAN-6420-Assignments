import random

# Define a Worker class
class Worker:
    def __init__(self, id, name, gender, salary):
        self.id = id
        self.name = name
        self.gender = gender
        self.salary = salary
        self.employee_level = self.assign_employee_level()
    
    def assign_employee_level(self):
        try:
            if 10000 < self.salary < 20000:
                return "A1"
            if 7500 < self.salary < 30000 and self.gender == "female":
                return "A5-F"
            return "Unknown"
        except Exception as e:
            print(f"Error assigning employee level for worker {self.id}: {e}")
            return "Error"

    def generate_payment_slip(self):
        try:
            slip = (
                f"Payment Slip for {self.name} (ID: {self.id}):\n"
                f"Gender: {self.gender}\n"
                f"Salary: ${self.salary}\n"
                f"Employee Level: {self.employee_level}\n"
            )
            return slip
        except Exception as e:
            print(f"Error generating payment slip for worker {self.id}: {e}")
            return "Error generating payment slip"

# Generate a list of 400 workers
worker_list = []
for i in range(1, 401):
    try:
        name = f"Worker_{i}"
        gender = random.choice(["male", "female"])
        salary = random.uniform(5000, 35000)
        worker = Worker(id=i, name=name, gender=gender, salary=salary)
        worker_list.append(worker)
    except Exception as e:
        print(f"Error creating worker {i}: {e}")

# Generate payment slips for each worker
for worker in worker_list:
    try:
        payment_slip = worker.generate_payment_slip()
        print(payment_slip)
    except Exception as e:
        print(f"Error processing worker {worker.id}: {e}")
