
# Project Title

A Python program to facilitate the weekly payments of workers

Description
How to Run the Python Version
-Make sure you have Python installed on your system. You can download it from python.org.
Place the attached script in a directory of your choice.

-Open a terminal or command prompt and navigate to the directory containing the attached script.

-Run the script
- The program will dynamically generate worker data, calculate their payments, determine their employee levels, and display the results.

R Version
-Make sure you have R installed on your system. You can download it from r-project.org.

-Place the R script in a directory of your choice.

-Open RStudio or any other R environment.

-Set the working directory to the directory containing the R script.

-Run the script 
-The program will dynamically generate worker data, calculate their payments, determine their employee levels, and display the results.

ADDITIONAL NOTE;

The Worker class in both Python and R scripts defines the structure of a worker, including attributes such as name, hourly rate, hours worked, and gender.

The payment calculation and employee level determination logic are encapsulated in functions/methods within each script.

Exception handling is included to address potential errors during payment calculation.

The scripts generate payment slips for a list of 400 workers, demonstrating dynamic data generation and processing.
