Flask Web Application for Data Collection
This Flask web application allows users to submit their information, which is then stored in a MongoDB database. The collected data includes user details such as name, age, gender, and total income, along with expense categories. Additionally, a Python class named "User" is provided for data processing, and the collected data can be exported to a CSV file for further analysis in a Jupyter notebook. Finally, the application is hosted on AWS Elastic Beanstalk.

Instructions for Use
1. Setting Up the Flask Application
Clone or download this repository to your local machine.
Make sure you have Python and Flask installed.

2. Installing Dependencies
Navigate to the project directory and install the required Python packages using 
pip:
pip install -r requirements.txt

3. Configuring MongoDB
Install MongoDB and make sure it's running on your local machine or on a cloud service.
Update the MongoDB connection string in the app.py file to connect to your MongoDB instance.

4. Running the Flask Application
Start the Flask application by running the following command:
python app.py
The application will be running on http://localhost:5000.

5. Collecting Data
Open a web browser and navigate to http://localhost:5000.
Fill in the form with your details and submit the information.

6. Data Processing and Analysis
The collected data is stored in MongoDB and can be accessed for further processing.
Use the provided Python class named "User" to process the data as needed.
Export the data to a CSV file using the provided functionality in the application.
Load the CSV file into a Jupyter notebook for data analysis and visualization.

7. Visualizations
Perform visualizations in the Jupyter notebook as described in the analysis instructions.
Export the charts for use in a presentation.

8. Hosting on AWS
Follow the steps outlined in the README.md file for hosting the Flask application on AWS Elastic Beanstalk.



