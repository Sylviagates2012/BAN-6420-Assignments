#15 People Data for Good evaluation

import csv

class User:
    def __init__(self, name, age, gender, total_income, expenses):
        self.name = name
        self.age = age
        self.gender = gender
        self.total_income = total_income
        self.expenses = expenses

def save_to_csv(users, filename):
    with open(filename, 'w', newline='') as csvfile:
        fieldnames = ['Name', 'Age', 'Gender', 'Total Income', 'Utilities', 'Entertainment', 'School Fees', 'Shopping', 'Healthcare']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        
        writer.writeheader()
        for user in users:
            writer.writerow({
                'Name': user.name,
                'Age': user.age,
                'Gender': user.gender,
                'Total Income': user.total_income,
                'Utilities': user.expenses.get('utilities', ''),
                'Entertainment': user.expenses.get('entertainment', ''),
                'School Fees': user.expenses.get('school_fees', ''),
                'Shopping': user.expenses.get('shopping', ''),
                'Healthcare': user.expenses.get('healthcare', '')
            })

# Sample data for 15 people
users_data = [
    {
        'name': 'John',
        'age': 30,
        'gender': 'Male',
        'total_income': 5000,
        'expenses': {
            'utilities': 200,
            'entertainment': 300,
            'school_fees': 400,
            'shopping': 500,
            'healthcare': 100
        }
    },
    {
        'name': 'Jane',
        'age': 25,
        'gender': 'Female',
        'total_income': 4500,
        'expenses': {
            'utilities': 150,
            'entertainment': 250,
            'school_fees': 350,
            'shopping': 450,
            'healthcare': 80
        }
    },
    {
        'name': 'Alice',
        'age': 35,
        'gender': 'Female',
        'total_income': 6000,
        'expenses': {
            'utilities': 250,
            'entertainment': 400,
            'school_fees': 300,
            'shopping': 600,
            'healthcare': 120
        }
    },
    {
        'name': 'Bob',
        'age': 28,
        'gender': 'Male',
        'total_income': 4800,
        'expenses': {
            'utilities': 180,
            'entertainment': 220,
            'school_fees': 370,
            'shopping': 420,
            'healthcare': 90
        }
    },
    {
        'name': 'Emily',
        'age': 40,
        'gender': 'Female',
        'total_income': 5500,
        'expenses': {
            'utilities': 220,
            'entertainment': 350,
            'school_fees': 450,
            'shopping': 550,
            'healthcare': 150
        }
    },
    {
        'name': 'Michael',
        'age': 32,
        'gender': 'Male',
        'total_income': 5200,
        'expenses': {
            'utilities': 240,
            'entertainment': 380,
            'school_fees': 420,
            'shopping': 480,
            'healthcare': 130
        }
    },
    {
        'name': 'Sophia',
        'age': 27,
        'gender': 'Female',
        'total_income': 4700,
        'expenses': {
            'utilities': 160,
            'entertainment': 280,
            'school_fees': 320,
            'shopping': 400,
            'healthcare': 70
        }
    },
    {
        'name': 'William',
        'age': 45,
        'gender': 'Male',
        'total_income': 5800,
        'expenses': {
            'utilities': 280,
            'entertainment': 450,
            'school_fees': 500,
            'shopping': 650,
            'healthcare': 200
        }
    },
    {
        'name': 'Olivia',
        'age': 29,
        'gender': 'Female',
        'total_income': 4900,
        'expenses': {
            'utilities': 190,
            'entertainment': 320,
            'school_fees': 380,
            'shopping': 440,
            'healthcare': 110
        }
    },
    {
        'name': 'James',
        'age': 38,
        'gender': 'Male',
        'total_income': 6300,
        'expenses': {
            'utilities': 300,
            'entertainment': 500,
            'school_fees': 600,
            'shopping': 700,
            'healthcare': 250
        }
    },
    {
        'name': 'Ella',
        'age': 26,
        'gender': 'Female',
        'total_income': 4600,
        'expenses': {
            'utilities': 170,
            'entertainment': 290,
            'school_fees': 340,
            'shopping': 420,
            'healthcare': 90
        }
    },
    {
        'name': 'Alexander',
        'age': 33,
        'gender': 'Male',
        'total_income': 5100,
        'expenses': {
            'utilities': 230,
            'entertainment': 360,
            'school_fees': 430,
            'shopping': 510,
            'healthcare': 140
        }
    },
    {
        'name': 'Mia',
        'age': 31,
        'gender': 'Female',
        'total_income': 5400,
        'expenses': {
            'utilities': 260,
            'entertainment': 420,
            'school_fees': 470,
            'shopping': 570,
            'healthcare': 180
        }
    },
    {
        'name': 'Benjamin',
        'age': 42,
        'gender': 'Male',
        'total_income': 6000,
        'expenses': {
            'utilities': 270,
            'entertainment': 480,
            'school_fees': 550,
            'shopping': 620,
            'healthcare': 220
        }
    },
    {
        'name': 'Charlotte',
        'age': 30,
        'gender': 'Female',
        'total_income': 5200,
        'expenses': {
            'utilities': 240,
            'entertainment': 380,
            'school_fees': 420,
            'shopping': 480,
            'healthcare': 130
        }
    }
]

# Convert data to User objects
users = [User(user['name'], user['age'], user['gender'], user['total_income'], user['expenses']) for user in users_data]

# Save data to CSV
save_to_csv(users, 'user_data.csv')
