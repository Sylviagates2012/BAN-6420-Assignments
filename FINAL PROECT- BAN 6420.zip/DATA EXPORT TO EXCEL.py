#Exporting all data to excel file

import pymongo
import pandas as pd

# Connect to MongoDB
client = pymongo.MongoClient("mongodb://localhost:27017/")
db = client["survey_data"]
collection = db["users"]

# Fetch all documents from the collection
cursor = collection.find({})

# Convert MongoDB documents to a DataFrame
df = pd.DataFrame(list(cursor))

# Save DataFrame to CSV file
df.to_csv('survey_data.csv', index=False)
