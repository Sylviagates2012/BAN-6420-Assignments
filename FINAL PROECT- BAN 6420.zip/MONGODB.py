import pymongo

# Connect to MongoDB
client = pymongo.MongoClient("mongodb://localhost:27017/")
db = client["survey_data"]  # Use the correct name for your database
collection = db["users"]  # Use the correct name for your collection

# Fetch all documents from the collection
cursor = collection.find({})

# Iterate over the cursor to access each document
for document in cursor:
    print(document)
