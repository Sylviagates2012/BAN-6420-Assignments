# Load required libraries
library(ggplot2)
library(dplyr)

# Set working directory
setwd("C:/Users/USER/Downloads")

# Import data
netflix_data <- read.csv("Netflix_shows_movies.csv")

# Most watched genres
most_watched_genres <- netflix_data %>%
  group_by(listed_in) %>%
  summarise(watch_counts = n()) %>%
  top_n(10, watch_counts) %>%
  arrange(desc(watch_counts))

# Bar plot for most watched genres
ggplot(most_watched_genres, aes(x = reorder(listed_in, watch_counts), y = watch_counts)) +
  geom_bar(stat = "identity", fill = "skyblue") +
  labs(title = "Most Watched Genres on Netflix",
       x = "Genres",
       y = "Watch Counts") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# Ratings distribution
ratings_distribution <- netflix_data %>%
  group_by(rating) %>%
  summarise(counts = n()) %>%
  arrange(desc(counts))

# Bar plot for ratings distribution
ggplot(ratings_distribution, aes(x = reorder(rating, -counts), y = counts)) +  # Changed reorder to -counts to sort in descending order
  geom_bar(stat = "identity", fill = "lightgreen") +
  labs(title = "Ratings Distribution on Netflix",
       x = "Ratings",
       y = "Counts") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))
