Breast Cancer Classification using PCA and Logistic Regression

This project demonstrates how to perform breast cancer classification using Principal Component Analysis (PCA) for dimensionality reduction and Logistic Regression for prediction. The dataset used is the breast cancer dataset available in the scikit-learn library.

Overview
Breast cancer is one of the most common cancers among women worldwide. Early detection and accurate diagnosis are crucial for effective treatment. In this project, we utilize PCA to reduce the dimensionality of the breast cancer dataset and then apply logistic regression to classify tumors as benign or malignant.

Instructions
Requirements
Python 3.x
Required Python libraries: numpy, pandas, scikit-learn, matplotlib

Setup
Install Python: If you haven't already, install Python 3.x from python.org.
Install Required Libraries: Install required libraries by running the following command in your terminal or command prompt:
Copy code
pip install numpy pandas scikit-learn matplotlib
Running the Code
Clone Repository: Clone this repository to your local machine:
bash
Copy code
git clone https://github.com/your-username/breast-cancer-classification.git
cd breast-cancer-classification
Run the Script: Run the Python script to perform PCA and logistic regression:
Copy code
python breast_cancer_classification.py
Results
The script will perform PCA on the breast cancer dataset and plot the PCA components.
It will then train a logistic regression model on the reduced dataset and evaluate its performance.
Results include accuracy, precision, recall, and F1-score for each class, along with a classification report.
File Description
breast_cancer_classification.py: Python script containing the code for performing PCA and logistic regression.
